@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo ========================================================
echo   Home - A Unique Horror Adventure 日本語化パッチャー
echo ========================================================
echo.

if exist "Home_JP_Patcher.exe" (
    Home_JP_Patcher.exe
) else (
    py -3 patcher.py
)

if %ERRORLEVEL% neq 0 (
    echo.
    echo 実行中にエラーが発生しました。
    pause
)
